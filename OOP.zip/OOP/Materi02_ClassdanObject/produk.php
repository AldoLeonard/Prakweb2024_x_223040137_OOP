<?php


//Jualan produk
//Komik
//Game
class Produk {

}

$produk1 = new Produk();
$produk2 = new Produk();


?>